#include "lista.h"
#include <math.h>
#include <pthread.h>
#define limit_p 2

typedef struct
{
    Lista* indicador;
    int *cores, *cores_f;
    int qt_v;
    int qt_cor;

} Grafo;

typedef struct
{
    Grafo *g;
    int *buffer;
    int *cores, *cores_f;
    int qt_cor;
} Paralelo;

void heuristica(Grafo *f);
void permuta_forca_bruta_p(Paralelo *p,int* buffer ,int k ,int *buffer_t, pthread_t *t_id);
void forca_bruta_p(Grafo *f);
void *colore_grafo_p(void *paramentros);
void forca_bruta(Grafo *f);
void permuta_forca_bruta(Grafo *f, int* buffer, int k);
void Mont_grafo(Lista *l,Grafo *f,double *raio,int qt_itens);
void limpa_grafo(Grafo *f);
void colore_grafo (Grafo *f, int* buffer);

