#include<stdlib.h>
#include<stdio.h>

typedef struct _Celula
{
    int chave;
    struct _Celula * proximo;
    struct _Celula * anterior;

} Celula;

typedef Celula* Apontador;

typedef struct
{
    Apontador primeiro;
    Apontador fim;

} Lista;

typedef int TipoChave;


void FLVazia(Lista *l);
int Busca_l(TipoChave chave, Lista *l, Apontador *celula);
void Insere_l(TipoChave x, Apontador posicao,Lista *l);
int Remove_l(Apontador posicao, Lista *l);

