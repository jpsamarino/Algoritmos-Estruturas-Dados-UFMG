#include <stdio.h>
#include <stdlib.h>
#include "memoria.h"

int main()
{
    Lista teste;
    Apontador buffer_celula;
    FLVazia(&teste);
    printf("%d\n",Busca_l(5, &teste,&buffer_celula));
    Insere_l(4,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    Insere_l(1,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    Insere_l(2,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(2, &teste,&buffer_celula));
    Remove_l(buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(1, &teste,&buffer_celula));
    Insere_l(2,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    Remove_l(teste.primeiro,&teste);
    Remove_l(teste.primeiro,&teste);
    Remove_l(teste.fim,&teste);
    imprime_l(&teste);
    return 0;
}
