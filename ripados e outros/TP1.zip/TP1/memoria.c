#include"memoria.h"
int insere_rlu(Memoria_principal* mp, int indicador) // retorna -1 quando pages fault ou N representado o numero de passos necessarios para colocar o indicador no inicio
{




}
