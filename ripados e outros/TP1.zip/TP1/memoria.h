#include "lista.h"

typedef struct
{
    int tamanho_total;
    int tamanho_pagina;
    Lista pagina;

} Memoria_principal;
