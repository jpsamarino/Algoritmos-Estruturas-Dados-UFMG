#include <stdio.h>
#include <stdlib.h>
#include "memoria.h"

int main()
{
    Lista teste;
    Apontador buffer_celula;
    Memoria_principal mp_t;
    mp_t.tamanho_pagina = 4;
    mp_t.tamanho_total = 8;
    prepara_memoria(&mp_t, mp_t.tamanho_pagina, mp_t.tamanho_total);
    printf("%d\n",insere_fifo(&mp_t,0));
    printf("%d\n",insere_fifo(&mp_t,2));
    printf("%d\n",insere_fifo(&mp_t,4));
    printf("%d\n",insere_fifo(&mp_t,2));
    printf("%d\n",insere_fifo(&mp_t,10));
    printf("%d\n",insere_fifo(&mp_t,1));
    printf("%d\n",insere_fifo(&mp_t,0));
    printf("%d\n",insere_fifo(&mp_t,0));
    printf("%d\n",insere_fifo(&mp_t,6));
    printf("%d\n",insere_fifo(&mp_t,8));

    /*FLVazia(&teste);
    printf("%d\n",Busca_l(5, &teste,&buffer_celula));
    Insere_l(4,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    Insere_l(1,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    Insere_l(2,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(2, &teste,&buffer_celula));
    Remove_l(buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(1, &teste,&buffer_celula));
    Insere_l(2,buffer_celula,&teste);
    imprime_l(&teste);
    printf("%d\n",Busca_l(4, &teste,&buffer_celula));
    limpa_l(&teste);
    imprime_l(&teste);*/


    return 0;
}
