#include <stdio.h>
#include <stdlib.h>
#include "grafos.h"

int main()
{
    Lista buffer;
    Grafo f;
    Apontador buffer_celula;
    FLVazia(&buffer);
    float raio = 5;





    Insere_l(1,buffer.primeiro,&buffer,-3,3);
    Insere_l(2,buffer.primeiro,&buffer,0,3);
    Insere_l(3,buffer.primeiro,&buffer,3,3);
    Insere_l(4,buffer.primeiro,&buffer,-3,0);
Insere_l(5,buffer.primeiro,&buffer,0,-5);
//il(&buffer);
    //buffer_celula = Busca_l(5,&buffer);
    Mont_grafo(&buffer,&f,&raio,5);
    //printf("\npp%dpp",f.indicador[4].primeiro->chave);
    //permuta_forca_bruta(&f,&j,0);
    //forca_bruta(&f);
    heuristica(&f);
    //forca_bruta_p(&f);
    //colore_grafo(&f,&j);
    printf("%d %d %d %d %d \n",f.cores_f[0],f.cores_f[1],f.cores_f[2],f.cores_f[3],f.cores_f[4]);
    printf(" 888 %d 888",f.qt_cor);
    ip(&f);

    //Remove_l(mp->pagina.fim,&(mp->pagina));
    //Busca_l(indicador_valido,&(mp->pagina),&buffer_celula);
    //Insere_l(indicador_valido,mp->pagina.primeiro,&(mp->pagina),0);
    return 0;
}
