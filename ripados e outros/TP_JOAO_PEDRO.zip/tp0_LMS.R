######by:JOAO PEDRO SAMARINO####MAT:2013048933################################
dados<- read.table(file='validacao_adaline.txt', header=FALSE);#recebe matriz
buffer <-  sample ( nrow (dados))
dados<-dados[buffer,] #embaralha

resp<-dados[,ncol(dados)]
entrada<-dados[,-ncol(dados)]

quantidade_linhas_entrada <-length(entrada) 

alpha  =  0.001 #taxa de aprendizagem
entrada = cbind(1,entrada) #add coluna com 1

quantidade_colunas_entrada <-ncol(entrada)

pesos=runif(quantidade_colunas_entrada,0,1) # gera valores uniformes para pesos

for(a in 1:1000) #numero intera��o
{ 
  #alpha = 1/(1+(a/5)) > modo dinamico melhor para a taxa de aprendizagem
  
  
  for(i in 1:quantidade_linhas_entrada)
    {
    
    h<-pesos%*%t(t(entrada[i,])) # valor parcial
    #print(h)
    for(j in 1:quantidade_colunas_entrada){
      
      pesos[j]= pesos[j]- alpha*(h-resp[i])*entrada[i,j] #LMS
    
    }
    
    
  } 
  
}


plot(dados)

abline(pesos[1],pesos[2])
