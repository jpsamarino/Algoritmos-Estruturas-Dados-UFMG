######by:JOAO PEDRO SAMARINO####MAT:2013048933################################
dados<- read.table(file='validacao_adaline.txt', header=FALSE);#recebe matriz
buffer <-  sample ( nrow (dados))
dados<-dados[buffer,] #embaralha

resp<-dados[,ncol(dados)]
entrada<-dados[,-ncol(dados)]

quantidade_linhas_entrada <-length(entrada) 

alpha  =  0.001 #taxa de aprendizagem
entrada = cbind(1,entrada) #add coluna com 1 para o termo independente

quantidade_colunas_entrada <-ncol(entrada)

pesos <- runif(quantidade_colunas_entrada,0,1)
valor_custo = entrada[1,]

for(k in 1:300)#numero de intera��es
{
  for(i in 1:quantidade_linhas_entrada)
  {
    for(z in 1:quantidade_colunas_entrada)#limpa valores de valor_custo
    {
      valor_custo[z]=0
    }
    #metodos dos quadrados medios
    for(j in 1:quantidade_linhas_entrada)#loop responsavel pelo somatorio
    {
      valor_parcial<-0
      
      for(z in 1:quantidade_colunas_entrada)
      {
      valor_parcial <- valor_parcial + pesos[z]*entrada[j,z]
      }
      for(z in 1:quantidade_colunas_entrada)
      {
      valor_custo[z] = valor_custo[z] + (valor_parcial-resp[j])*entrada[j,z]
      }
    }
    
    for(z in 1:quantidade_colunas_entrada)
    {
     pesos[z]=pesos[z]-alpha*valor_custo[z]*entrada[i,z]
    }
  
  }
}

plot(dados)
abline(pesos[1],pesos[2])