######by:JOAO PEDRO SAMARINO####MAT:2013048933################################
arquivo<- read.table(file='C:/Users/Jo�o Pedro/Desktop/Redes Neurais Artificiais/Perceptron/validacao_perceptron.txt', header=FALSE);

resp<-arquivo[,ncol(arquivo)]
entrada<-arquivo[,-ncol(arquivo)]

alpha  =  0.001  #taxa de aprendizado

flag = TRUE #indica quando os dados foram separados - TRUE: ainda n�o - FALSE: separados

q_coluna_entrada<-ncol(entrada)
q_linha_entrada<-nrow(entrada)
teste =1
pesos=runif(q_coluna_entrada,0,1) #pesos entrada

#sem o termo independente tambem � capaz de convergir
while(flag)
{
  teste=teste+1
  flag=FALSE
  
  for(i in 1:q_linha_entrada)
  {
    valida = 0
    
    for(j in 1:q_coluna_entrada) #processo mais rapido que produto cruzado tradicional
    {
      valida <- valida + entrada[i,j]*pesos[j]
      
    }
    
    if(valida<=0)
    {
      h = 0
    }
    else
    {
      h = 1 
    }
    
    erro =  resp[i] - h
    
    if(erro!=0)
    {
      #pesos = pesos + erro*alpha*entrada[i,] -  modo lento
      for(j in 1:q_coluna_entrada) #modo mais rapido
      {
        pesos[j] = pesos[j]+erro*alpha*entrada[i,j]
      }
      flag = TRUE
    }
    
  }
  
  
}

print("quantidade de intera�oes realizadas para convergir:"); print(teste);

